# Quiz-application-in-python

A simple Quiz application in Python programming lanaguage completed as a mini project.

## Usage

```powershell
    python quiz.py
```

## Features

- Admin and Player

- Login as **admin** to add more questions

- Login as **player** to play quiz



## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
